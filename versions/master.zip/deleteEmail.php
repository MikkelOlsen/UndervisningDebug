<?php

$email->deleteEmail($_GET['id']);
$user->redirect('beskeder');
